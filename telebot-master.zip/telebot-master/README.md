# telebot

[![Managed by Zerocracy](http://www.0crat.com/badge/C6KLDT6QG.svg)](http://www.0crat.com/p/C6KLDT6QG)
[![PDD status](http://www.0pdd.com/svg?name=DronMDF/telebot)](http://www.0pdd.com/p?name=DronMDF/telebot)
[![License](https://img.shields.io/badge/license-MIT-green.svg)](https://github.com/DronMDF/telebot/blob/master/LICENSE)

[Как подключиться к проекту](ENTRY.md)

 ／|、  
 (ﾟ､ 。7  
︱ ︶ヽ  
_U U c )ノ
