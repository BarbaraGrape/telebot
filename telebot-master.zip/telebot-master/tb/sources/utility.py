class SoJoin:
	def __init__(self, *sources):
		self.sources = sources

	def actions(self):
		# @todo #47 Необходимо собрать actions со всех внутренних
		#  источников и вернуть в виде общего списка
		return []
